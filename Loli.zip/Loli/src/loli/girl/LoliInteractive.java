package loli.girl;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import lettore.immagini.LeggiImmagine;

public class LoliInteractive {

	private JFrame frame;
	private String[] listaImmagini;
	private JFrame frameProvvisorio;
	private LoliModel model;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoliInteractive window = new LoliInteractive();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LoliInteractive() {
		listaImmagini=LeggiImmagine.leggiImaggini("Immagini");
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(700, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		frameProvvisorio=new JFrame();
		frameProvvisorio.setBounds(100, 100, 450, 300);
		frameProvvisorio.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frameProvvisorio.setVisible(true);
		frameProvvisorio.getContentPane().add(new JLabel("Questo � un frame provvisorio"));
		
		model=new LoliModel(listaImmagini.length);
		
		LoliPanel loliPanel = new LoliPanel();
		loliPanel.setBounds(44, 27, 300, 100);
		frame.getContentPane().add(loliPanel);
		loliPanel.initialize(listaImmagini.length);
		
		JProgressBar progressBar = new JProgressBar();
		progressBar.setBounds(44, 207, 340, 14);
		frame.getContentPane().add(progressBar);
		progressBar.setMaximum(listaImmagini.length);
		progressBar.setValue(progressBar.getMaximum());
		
		JButton btnAuguri = new JButton("AUGURI!");
		btnAuguri.setBounds(176, 159, 89, 23);
		frame.getContentPane().add(btnAuguri);
		btnAuguri.setVisible(false);
		
		JButton btnAutomatico = new JButton("AUTOMATICO");
		btnAutomatico.setBounds(176, 159, 89, 23);
		frame.getContentPane().add(btnAutomatico);
		btnAutomatico.setVisible(true);
		
		progressBar.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent che) {
				model.setCounter(progressBar.getValue());
			}
		});
		
		model.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent che) {
				if(progressBar.getValue()!=0)
					progressBar.setValue(model.getCounter());
				else {
					loliPanel.setVisible(false);
					btnAuguri.setVisible(true);
				}
			}
		});
		
		loliPanel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoliNumber ln=(LoliNumber)e;
				int imageIndex=ln.extractDigit();
				leggiImmagineConChiusura(imageIndex-1);//altrimenti all'ultima c'� nullptr
				model.decrementa();
			}
		});
		
		btnAuguri.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frameProvvisorio.setVisible(false);
				LeggiImmagine.chiudiFrame(frameProvvisorio);
				try {
					generaFrame("AUGURI",100,150);
					generaFrame("GIUSY!",250,400);
				} catch (InterruptedException ex) {
					ex.printStackTrace();
				}
			}
		});
		
		btnAutomatico.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loliPanel.setVisible(false);
				model.setCounter(0);
				btnAutomatico.setVisible(false);
				btnAuguri.setVisible(true);
				visualizzaAutomatico();
			}
		});
	}
	
	private void leggiImmagineConChiusura(int index) {
		LeggiImmagine.chiudiFrame(frameProvvisorio);
		frameProvvisorio=LeggiImmagine.leggiImmagine("./Immagini/"+listaImmagini[index]);
		frameProvvisorio.setVisible(true);
	}
	
	private void generaFrame(String word, int x,int y) throws InterruptedException {
		frame.setVisible(false);
		LeggiImmagine.chiudiFrame(frame);
		for(int i=0;i<word.length();i++, x+=140) {
			JFrame frame=creaFrame(x,y);
			LoliPanelPaint lpp=new LoliPanelPaint(word.charAt(i),i,i);
			lpp.setBounds(0,0, frame.getHeight(), frame.getWidth());
			frame.getContentPane().add(lpp);
			Thread.sleep(1000);
		}
	}
	
	private JFrame creaFrame(int x,int y) {
		JFrame frame=new JFrame();
		frame.setBounds(x,y,100,150);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		return frame;
	}
	
	private void visualizzaAutomatico() {
		final CardLayOutLoli cll=new CardLayOutLoli(listaImmagini);
		cll.setVisible(true);
		cll.setBounds(100,100,350,400);
		cll.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Timer t=new Timer();
		t.schedule(new TimerTask() {
		public void run() {cll.changeCard();}
		},0,1000);
	}
}
