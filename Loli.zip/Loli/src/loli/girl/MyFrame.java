package loli.girl;

import javax.swing.JFrame;

import lettore.immagini.LeggiImmagine;

public class MyFrame extends JFrame implements Runnable {
	
	private JFrame frame;
	private String nomeImmagine;
	
	public MyFrame(String nomeImmagine) {
		this.nomeImmagine=nomeImmagine;
		frame=LeggiImmagine.leggiImmagine("./Immagini/"+nomeImmagine);
	}

	@Override
	public void run() {
		frame.setVisible(true);
		try {
			Thread.sleep(2000);
			LeggiImmagine.chiudiFrame(frame);
		}catch(InterruptedException e) {
			System.out.println("Mi hai interrotto");
		}
	}

}
