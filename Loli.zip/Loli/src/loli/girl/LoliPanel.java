package loli.girl;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JPanel;

public class LoliPanel extends JPanel {
	
	private ArrayList<ActionListener> listenerList=new ArrayList<ActionListener>();

	/**
	 * Create the panel.
	 */
	public LoliPanel() {
		setLayout(new GridLayout(4, 4));
		setBackground(Color.ORANGE);
	}
	
	public void initialize(int number) {
		for(int i=0;i<number;i++) {
			addButton(i);
		}
	}
	
	private void addButton(int index) {
		JButton loliButton=new JButton("Loli "+(index+1));
		this.add(loliButton);
		loliButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoliNumber ln=new LoliNumber(this,0,loliButton.getText());
				fireActionPerformed(ln);
			}
		});
	}
	
	protected void fireActionPerformed(ActionEvent e) {
		for (ActionListener actionListener : listenerList) {
			actionListener.actionPerformed(e);
		}
	}
	
	public void addActionListener(ActionListener al) {
		listenerList.add(al);
	}
	
}
