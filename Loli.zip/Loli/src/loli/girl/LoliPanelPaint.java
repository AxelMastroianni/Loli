package loli.girl;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

public class LoliPanelPaint extends JPanel {

	private final Color[] colori=new Color[] {Color.RED,Color.ORANGE,Color.YELLOW,Color.GREEN,
			Color.BLUE,Color.MAGENTA};
//	private final String[] happyBirthday=new String[] {"A","U","G","U","R","I"};
	private int letterIndex;
	private int colorIndex;
	private char word;
	/**
	 * Create the panel.
	 */
	public LoliPanelPaint(char word,int letterIndex, int colorIndex) {
		this.word=word;
		this.letterIndex=letterIndex;
		this.colorIndex=colorIndex;
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2=(Graphics2D)g;
		g2.setFont(new Font("monospace",Font.ITALIC,70));
		g2.setColor(colori[colorIndex]);
		g2.drawString(String.format("%c",word), this.getWidth()/2, this.getHeight()/2);
	}

}
