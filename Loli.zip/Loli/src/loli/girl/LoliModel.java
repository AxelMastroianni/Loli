package loli.girl;

import java.util.ArrayList;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class LoliModel {
	
	private int counter;
	private ArrayList<ChangeListener> listenerList = new ArrayList<ChangeListener>();
	
	public LoliModel(int counter) {
		this.counter=counter;
	}
	
	public void setCounter(int counter) {
		if(counter>=0) {
			this.counter=counter;
			fireValuesChange(new ChangeEvent(this));
		}
	}
	
	public int getCounter() {
		return counter;
	}
	
	public void decrementa() {
		setCounter(counter-1);
	}
	
	public void addChangeListener(ChangeListener chl) {
		listenerList.add(chl);
	}
	
	protected void fireValuesChange(ChangeEvent e) {
		for (ChangeListener changeListener : listenerList) {
			changeListener.stateChanged(e);
		}
	}

}
