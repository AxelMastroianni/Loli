package loli.girl;

import java.awt.CardLayout;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;

import lettore.immagini.LeggiImmagine;

public class CardLayOutLoli extends JFrame {
	
	private CardLayout card_layout;
	private JPanel main_panel;
	private String[] listaImmagini;
	
	public CardLayOutLoli(String[] listaImmagini) {
		this.listaImmagini=listaImmagini;
		card_layout=new CardLayout();
		main_panel=new JPanel();
		main_panel.setSize(this.getSize());
		main_panel.setVisible(true);
		main_panel.setLayout(card_layout);
		for(int i=0;i<listaImmagini.length;i++) {
			JPanel panel=LeggiImmagine.leggiImg("./Immagini/"+listaImmagini[i]);
			main_panel.add(panel,"foto "+i);
		}
	}
	
	public void changeCard() {
		for(int i=0;i<listaImmagini.length;i++) {
			card_layout.show(main_panel,"foto "+i);
		}
	}

}
