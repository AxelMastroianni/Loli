package loli.girl;

import java.awt.event.ActionEvent;

public class LoliNumber extends ActionEvent {
	
	private String name;
	
	public LoliNumber(Object src,int id,String name) {
		super(src,id,null);
		this.name=name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public int extractDigit() {
		StringBuilder sb=new StringBuilder();
		for(int i=0;i<name.length();i++) {
			if(name.charAt(i)>='0' && name.charAt(i)<='9')
				sb.append(name.charAt(i));
		}
		return Integer.parseInt(sb.toString());
	}
	

}
